regret <- function(x) {
	if ( tolower(x)=="x" ) {
		print(ASJP())
	}
}
