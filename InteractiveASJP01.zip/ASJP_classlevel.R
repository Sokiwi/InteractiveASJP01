classlevel <- function(x) {
	return(strsplit(x, "")[[1]][2])
}
